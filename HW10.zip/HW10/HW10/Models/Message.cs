﻿namespace HW10.Models
{
    public class Message
    {
        public string mes { get; set; } = "";
        public string status { get; set; } = "success";
    }
}
