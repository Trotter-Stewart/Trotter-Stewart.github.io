﻿namespace HW11.Models
{
    public class Message
    {
        public string status { get; set; } = "success";

        public string mes { get; set; } = "";
    }
}
