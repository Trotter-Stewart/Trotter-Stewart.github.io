﻿using Microsoft.AspNetCore.Mvc;

namespace MVC_0402_1_.Controllers
{
    public class ThirdController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
