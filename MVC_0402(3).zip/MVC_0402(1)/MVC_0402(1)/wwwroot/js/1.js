﻿"use strict";

// define a block
{
    let opts =
    {
        title: "This is the thrid controller",
        text: "Third Index",
        icon: "success",
    };

    Swal.fire(opts);
}

