﻿using LC_MVC2_M.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace LC_MVC2_M.Controllers
{
    public class ProfileController : Controller
    {

        StuDB db = new StuDB();

        public JsonResult GetStus()
        {
            var r = db.Students.Select(x => new { id = x.Id, name = x.Name });
            return Json(r);
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
