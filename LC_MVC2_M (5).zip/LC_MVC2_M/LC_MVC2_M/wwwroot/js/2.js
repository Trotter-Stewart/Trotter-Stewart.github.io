﻿"use strict";

{// start block

    let grid = null; //js variable for the table
    let tbldiv = document.querySelector("#tbldiv");

    async function LoadTable()
    {
        //form data for parameters
        let fd = new FormData();


        //url
        let url = rootpath + "Home/GetAllStus";

        //opts
        let opts =
        {
            method: "post",
            cache: "no-store",
            body: fd,
        };


        // fetch() r rj
        let r = await fetch(url, opts);
        let rj = await r.json();


        //show in the table
        //1. Clear the table
        if (grid != null)
        {
            grid.destroy();
            grid = null;
        }
        tbldiv.innerHTML = "";

        //2. Show a new table
        opts = {
            data:rj,
        };
        grid = new gridjs.Grid(opts);
        grid.render(tbldiv);

    }// end of loadtabe function

    LoadTable();// call show table funtion



}// end of block